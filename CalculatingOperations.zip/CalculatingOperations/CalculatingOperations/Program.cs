﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        // Call the calculator function
        SimpleCalculator.PerformCalculation();
    }
}

public class SimpleCalculator
{
    public static void PerformCalculation()
    {
        double num1, num2, result;
        string operation;

        // Welcome message
        Console.WriteLine("Simple C# Calculator");

        // Input first number
        Console.Write("Enter first number: ");
        num1 = Convert.ToDouble(Console.ReadLine());

        // Input the operation
        Console.Write("Enter an operator (+, -, *, /): ");
        operation = Console.ReadLine();

        // Input second number
        Console.Write("Enter second number: ");
        num2 = Convert.ToDouble(Console.ReadLine());

        // Perform calculation based on the operation
        switch (operation)
        {
            case "+":
                result = num1 + num2;
                Console.WriteLine($"Result: {num1} + {num2} = {result}");
                break;

            case "-":
                result = num1 - num2;
                Console.WriteLine($"Result: {num1} - {num2} = {result}");
                break;

            case "*":
                result = num1 * num2;
                Console.WriteLine($"Result: {num1} * {num2} = {result}");
                break;

            case "/":
                if (num2 != 0)
                {
                    result = num1 / num2;
                    Console.WriteLine($"Result: {num1} / {num2} = {result}");
                }
                else
                {
                    Console.WriteLine("Error: Division by zero is not allowed.");
                }
                break;

            default:
                Console.WriteLine("Error: Invalid operator.");
                break;
        }

        // Pause before exit
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}

